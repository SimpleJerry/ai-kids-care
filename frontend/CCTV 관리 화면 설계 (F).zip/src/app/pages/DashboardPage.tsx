import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { TopBar } from '../components/TopBar';
import { Sidebar } from '../components/Sidebar';
import { CCTVGrid } from '../components/CCTVGrid';
import { RightPanel } from '../components/RightPanel';
import { CameraDetailModal } from '../components/CameraDetailModal';
import { EventDetailModal } from '../components/EventDetailModal';
import { FullscreenView } from '../components/FullscreenView';
import type { Camera, AnomalyEvent, AnomalyType } from '../types/anomaly';
import { rolePermissions } from '../types/anomaly';

const allCameras: Camera[] = [
  { id: 'CAM-001', name: '정문 입구', location: '1층 현관', status: 'online', isRecording: true, category: 'entrance' },
  { id: 'CAM-002', name: '놀이터', location: '야외 놀이공간', status: 'online', isRecording: true, category: 'playground' },
  { id: 'CAM-003', name: '햇살반 교실', location: '2층 201호', status: 'online', isRecording: true, category: 'classroom', assignedTeacher: 'teacher1' },
  { id: 'CAM-004', name: '무지개반 교실', location: '2층 202호', status: 'online', isRecording: true, category: 'classroom', assignedTeacher: 'teacher2' },
  { id: 'CAM-005', name: '별님반 교실', location: '3층 301호', status: 'online', isRecording: true, category: 'classroom', assignedTeacher: 'teacher3' },
  { id: 'CAM-006', name: '복도 A', location: '2층 중앙복도', status: 'online', isRecording: true, category: 'corridor' },
  { id: 'CAM-007', name: '복도 B', location: '3층 중앙복도', status: 'online', isRecording: true, category: 'corridor' },
  { id: 'CAM-008', name: '급식실', location: '1층 식당', status: 'online', isRecording: true, category: 'office' },
  { id: 'CAM-009', name: '운동장', location: '야외 운동공간', status: 'online', isRecording: true, category: 'playground' },
  { id: 'CAM-010', name: '후문', location: '1층 후문', status: 'online', isRecording: true, category: 'entrance' },
  { id: 'CAM-011', name: '주차장', location: '지상 주차장', status: 'online', isRecording: true, category: 'parking' },
  { id: 'CAM-012', name: '사무실', location: '1층 행정실', status: 'online', isRecording: true, category: 'office' },
];

const anomalyTypes: AnomalyType[] = [
  'Assault', 'Fight', 'Burglary', 'Vandalism', 'Swoon',
  'Wander', 'Trespass', 'Dump', 'Robbery', 'Datefight',
  'Kidnap', 'Drunken'
];

const generateMockEvents = (): AnomalyEvent[] => {
  const events: AnomalyEvent[] = [
    {
      id: 'EVT-001',
      timestamp: new Date(Date.now() - 2 * 60000),
      cameraId: 'CAM-001',
      cameraName: '정문 입구',
      type: 'Trespass',
      confidence: 95,
      location: '1층 현관',
      status: 'active',
      severity: 'high'
    },
    {
      id: 'EVT-002',
      timestamp: new Date(Date.now() - 15 * 60000),
      cameraId: 'CAM-009',
      cameraName: '운동장',
      type: 'Fight',
      confidence: 92,
      location: '야외 운동공간',
      status: 'reviewing',
      severity: 'high'
    },
    {
      id: 'EVT-003',
      timestamp: new Date(Date.now() - 45 * 60000),
      cameraId: 'CAM-002',
      cameraName: '놀이터',
      type: 'Wander',
      confidence: 78,
      location: '야외 놀이공간',
      status: 'resolved',
      severity: 'low'
    }
  ];

  return events.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
};

export function DashboardPage() {
  const { user, switchRole } = useAuth();
  const [cameras, setCameras] = useState<Camera[]>(allCameras);
  const [filteredCameras, setFilteredCameras] = useState<Camera[]>(allCameras);
  const [events, setEvents] = useState<AnomalyEvent[]>(generateMockEvents());
  const [layout, setLayout] = useState<'1x1' | '2x2' | '3x3'>('2x2');
  const [isRecording, setIsRecording] = useState(true);
  const [selectedCamera, setSelectedCamera] = useState<Camera | null>(null);
  const [selectedEvent, setSelectedEvent] = useState<AnomalyEvent | null>(null);
  const [fullscreenCamera, setFullscreenCamera] = useState<Camera | null>(null);
  const [categoryFilter, setCategoryFilter] = useState<'all' | Camera['category']>('all');
  const [isVideoPaused, setIsVideoPaused] = useState(false);

  useEffect(() => {
    if (!user) return;

    const permissions = rolePermissions[user.role];

    let availableCameras = allCameras;

    if (permissions.canViewAllCameras) {
      availableCameras = allCameras;
    } else if (permissions.canViewOwnClassroom) {
      if (user.role === 'teacher') {
        availableCameras = allCameras.filter(cam =>
          cam.category === 'classroom' && cam.assignedTeacher === 'teacher1'
        );
      } else if (user.role === 'guardian') {
        availableCameras = allCameras.filter(cam =>
          cam.category === 'classroom' || cam.category === 'playground'
        );
      }
    }

    setCameras(availableCameras);
    setFilteredCameras(availableCameras);
  }, [user]);

  useEffect(() => {
    if (categoryFilter === 'all') {
      setFilteredCameras(cameras);
    } else {
      setFilteredCameras(cameras.filter(cam => cam.category === categoryFilter));
    }
  }, [categoryFilter, cameras]);

  useEffect(() => {
    const interval = setInterval(() => {
      if (Math.random() < 0.1) {
        const randomCamera = allCameras[Math.floor(Math.random() * allCameras.length)];
        const randomType = anomalyTypes[Math.floor(Math.random() * anomalyTypes.length)];

        const newEvent: AnomalyEvent = {
          id: `EVT-${Date.now()}`,
          timestamp: new Date(),
          cameraId: randomCamera.id,
          cameraName: randomCamera.name,
          type: randomType,
          confidence: Math.floor(Math.random() * 30) + 70,
          location: randomCamera.location,
          status: 'active',
          severity: Math.random() > 0.7 ? 'high' : Math.random() > 0.4 ? 'medium' : 'low'
        };

        setEvents(prev => [newEvent, ...prev].slice(0, 10));
      }
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  const handleCameraSelect = (cameraId: string) => {
    const camera = cameras.find(c => c.id === cameraId);
    if (camera) {
      setSelectedCamera(camera);
    }
  };

  const handleCameraFullscreen = (cameraId: string) => {
    const camera = cameras.find(c => c.id === cameraId);
    if (camera) {
      setFullscreenCamera(camera);
    }
  };

  const handleEventClick = (eventId: string) => {
    const event = events.find(e => e.id === eventId);
    if (event) {
      setSelectedEvent(event);
    }
  };

  const handleEventResolve = () => {
    if (selectedEvent) {
      setEvents(prev => prev.map(e =>
        e.id === selectedEvent.id
          ? { ...e, status: 'resolved' as const, resolvedBy: user?.name, resolvedAt: new Date() }
          : e
      ));
      setSelectedEvent(null);
    }
  };

  const handleQuickFullscreen = () => {
    if (filteredCameras.length > 0) {
      setFullscreenCamera(filteredCameras[0]);
    }
  };

  const handleQuickPause = () => {
    setIsVideoPaused(!isVideoPaused);
  };

  const handleQuickDownload = () => {
    alert('영상 다운로드 기능이 실행됩니다.\n실제 환경에서는 선택된 카메라의 영상을 다운로드합니다.');
  };

  const handleCategoryFilter = (category: typeof categoryFilter) => {
    setCategoryFilter(category);
  };

  const cameraStats = {
    total: cameras.length,
    online: cameras.filter(c => c.status === 'online').length,
    offline: cameras.filter(c => c.status === 'offline').length
  };

  if (!user) return null;

  const permissions = rolePermissions[user.role];

  return (
    <>
      <div className="h-screen flex flex-col bg-gray-50">
        <TopBar
          currentRole={user.role}
          username={user.name}
          onRoleChange={switchRole}
        />

        <div className="flex-1 flex overflow-hidden">
          <Sidebar
            currentRole={user.role}
            userName={user.name}
            cameraStats={cameraStats}
            onCategoryFilter={handleCategoryFilter}
            currentCategory={categoryFilter}
          />

          <main className="flex-1 p-6 overflow-auto">
            <div className="mb-4">
              <h2 className="text-lg font-semibold text-gray-900">실시간 모니터링</h2>
              <p className="text-sm text-gray-500">
                {filteredCameras.length}개 카메라 활성화 중 • {layout === '1x1' ? '1×1' : layout === '2x2' ? '2×2' : '3×3'} 레이아웃
                {isVideoPaused && ' • 일시정지됨'}
              </p>
            </div>
            <CCTVGrid
              cameras={filteredCameras}
              onCameraSelect={handleCameraSelect}
              onCameraFullscreen={handleCameraFullscreen}
              layout={layout}
            />
          </main>

          <RightPanel
            events={events}
            onEventClick={handleEventClick}
            currentRole={user.role}
            onLayoutChange={setLayout}
            currentLayout={layout}
            isRecording={isRecording}
            onRecordingToggle={() => setIsRecording(!isRecording)}
            onQuickFullscreen={handleQuickFullscreen}
            onQuickPause={handleQuickPause}
            onQuickDownload={handleQuickDownload}
            isVideoPaused={isVideoPaused}
          />
        </div>
      </div>

      {selectedCamera && (
        <CameraDetailModal
          camera={selectedCamera}
          onClose={() => setSelectedCamera(null)}
          onFullscreen={() => {
            setFullscreenCamera(selectedCamera);
            setSelectedCamera(null);
          }}
        />
      )}

      {selectedEvent && (
        <EventDetailModal
          event={selectedEvent}
          onClose={() => setSelectedEvent(null)}
          onResolve={handleEventResolve}
          canResolve={permissions.canResolveAnomaly}
        />
      )}

      {fullscreenCamera && (
        <FullscreenView
          camera={fullscreenCamera}
          onClose={() => setFullscreenCamera(null)}
        />
      )}
    </>
  );
}
