import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import type { UserRole } from '../types/anomaly';

interface User {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  email?: string;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  switchRole: (role: UserRole) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const mockUsers: Record<string, { password: string; user: User }> = {
  'super': {
    password: 'admin123',
    user: {
      id: '1',
      username: 'super',
      name: '최고관리자',
      role: 'super_admin',
      email: 'super@kindergarten.com',
    },
  },
  'system': {
    password: 'admin123',
    user: {
      id: '2',
      username: 'system',
      name: '정시스템관리자',
      role: 'system_admin',
      email: 'system@kindergarten.com',
    },
  },
  'admin': {
    password: 'admin123',
    user: {
      id: '3',
      username: 'admin',
      name: '김원장',
      role: 'admin',
      email: 'admin@kindergarten.com',
    },
  },
  'teacher': {
    password: 'teacher123',
    user: {
      id: '4',
      username: 'teacher',
      name: '이선생',
      role: 'teacher',
      email: 'teacher@kindergarten.com',
    },
  },
  'guardian': {
    password: 'parent123',
    user: {
      id: '5',
      username: 'guardian',
      name: '박학부모',
      role: 'guardian',
      email: 'parent@example.com',
    },
  },
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const savedUser = localStorage.getItem('cctv_user');
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser));
      } catch (e) {
        localStorage.removeItem('cctv_user');
      }
    }
  }, []);

  const login = async (username: string, password: string): Promise<boolean> => {
    await new Promise(resolve => setTimeout(resolve, 500));

    const mockUser = mockUsers[username];
    if (mockUser && mockUser.password === password) {
      setUser(mockUser.user);
      localStorage.setItem('cctv_user', JSON.stringify(mockUser.user));
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('cctv_user');
  };

  const switchRole = (role: UserRole) => {
    if (user) {
      const updatedUser = { ...user, role };
      setUser(updatedUser);
      localStorage.setItem('cctv_user', JSON.stringify(updatedUser));
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        login,
        logout,
        switchRole,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
